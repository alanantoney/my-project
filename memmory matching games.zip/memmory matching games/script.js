const grid = document.getElementById("game-grid");
const restartBtn = document.getElementById("restart");

const emojis = ["🍎", "🍌", "🍇", "🍉", "🍒", "🍍", "🥝", "🍓"];
let cards = [...emojis, ...emojis]; // duplicate for pairs
let flippedCards = [];
let matchedCards = [];

function shuffle(array) {
  return array.sort(() => 0.5 - Math.random());
}

function createBoard() {
  grid.innerHTML = "";
  matchedCards = [];
  flippedCards = [];
  cards = shuffle(cards);

  cards.forEach((emoji, index) => {
    const card = document.createElement("div");
    card.classList.add("card");
    card.dataset.emoji = emoji;
    card.dataset.index = index;
    card.innerText = emoji;

    card.addEventListener("click", () => flipCard(card));
    grid.appendChild(card);
  });

  // hide emojis after 1.5s
  setTimeout(() => {
    document.querySelectorAll(".card").forEach((card) => {
      card.classList.remove("flipped");
      card.innerText = "";
    });
  }, 1500);
}

function flipCard(card) {
  if (
    flippedCards.length === 2 ||
    card.classList.contains("flipped") ||
    card.classList.contains("matched")
  ) {
    return;
  }

  card.classList.add("flipped");
  card.innerText = card.dataset.emoji;
  flippedCards.push(card);

  if (flippedCards.length === 2) {
    checkMatch();
  }
}

function checkMatch() {
  const [card1, card2] = flippedCards;
  if (card1.dataset.emoji === card2.dataset.emoji) {
    card1.classList.add("matched");
    card2.classList.add("matched");
    matchedCards.push(card1, card2);
    if (matchedCards.length === cards.length) {
      setTimeout(() => alert("🎉 You won!"), 300);
    }
  } else {
    setTimeout(() => {
      card1.classList.remove("flipped");
      card1.innerText = "";
      card2.classList.remove("flipped");
      card2.innerText = "";
    }, 800);
  }
  flippedCards = [];
}

restartBtn.addEventListener("click", createBoard);

createBoard();
