const chatWindow = document.getElementById("chatWindow");
const messageInput = document.getElementById("messageInput");

async function sendMessage() {
  const text = messageInput.value.trim();
  if (text === "") return;

  const msg = document.createElement("div");
  msg.className = "message sent";
  msg.textContent = text;
  chatWindow.appendChild(msg);

  messageInput.value = "";
  chatWindow.scrollTop = chatWindow.scrollHeight;

  // Use ChatGPT API for reply
  const reply = document.createElement("div");
  reply.className = "message received";
  reply.textContent = "...";
  chatWindow.appendChild(reply);
  chatWindow.scrollTop = chatWindow.scrollHeight;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": " 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"
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a helpful assistant." },
          { role: "user", content: text }
        ]
      })
    });

    const data = await response.json();
    reply.textContent = data.choices[0].message.content;
    chatWindow.scrollTop = chatWindow.scrollHeight;
  } catch (error) {
    reply.textContent = "Error:can't find anything.";
    console.error(error);
  }
}

messageInput.addEventListener("keypress", function (e) {
  if (e.key === "Enter") {
    sendMessage();
  }
});
