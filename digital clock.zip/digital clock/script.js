
function updateClock() {
  const now = new Date();
  let h = String(now.getHours()).padStart(2, '0');
  let m = String(now.getMinutes()).padStart(2, '0');
  let s = String(now.getSeconds()).padStart(2, '0');
  document.getElementById('clock-time').textContent = `${h}:${m}:${s}`;
}
setInterval(updateClock, 1000);
updateClock();


const tabs = document.querySelectorAll('.tab');
const contents = document.querySelectorAll('.tab-content');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    contents.forEach(c => c.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(tab.dataset.tab).classList.add('active');
  });
});
function setAlarm() {
  const alarmTime = document.getElementById('alarmTime').value;
  document.getElementById('alarmStatus').textContent = `Alarm set for ${alarmTime}`;
}

let stopwatchInterval;
let stopwatchTime = 0;

function formatTime(seconds) {
  const h = String(Math.floor(seconds / 3600)).padStart(2, '0');
  const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
  const s = String(seconds % 60).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

function startStopwatch() {
  if (!stopwatchInterval) {
    stopwatchInterval = setInterval(() => {
      stopwatchTime++;
      document.getElementById('stopwatch-display').textContent = formatTime(stopwatchTime);
    }, 1000);
  }
}

function stopStopwatch() {
  clearInterval(stopwatchInterval);
  stopwatchInterval = null;
}

function resetStopwatch() {
  stopStopwatch();
  stopwatchTime = 0;
  document.getElementById('stopwatch-display').textContent = '00:00:00';
}
let timerInterval;
function startTimer() {
  let minutes = parseInt(document.getElementById('timerMinutes').value);
  if (isNaN(minutes) || minutes <= 0) {
    alert("Please enter valid minutes");
    return;
  }

  let totalSeconds = minutes * 60;
  const display = document.getElementById('timer-display');

  clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    if (totalSeconds <= 0) {
      clearInterval(timerInterval);
      display.textContent = "Time's up!";
      return;
    }
    totalSeconds--;
    display.textContent = formatTime(totalSeconds);
  }, 1000);
}