async function translateText() {
  const inputText = document.getElementById("inputText").value;
  const sourceLang = document.getElementById("sourceLang").value;
  const targetLang = document.getElementById("targetLang").value;
  const output = document.getElementById("outputText");

  if (!inputText.trim()) {
    output.textContent = "Please enter some text.";
    return;
  }

  output.textContent = "Translating...";

  try {
    const res = await fetch("https://translate.astian.org/translate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        q: inputText,
        source: sourceLang,
        target: targetLang,
        format: "text"
      }),
    });

    const data = await res.json();
    output.textContent = data.translatedText || "No translation received.";
  } catch (err) {
    output.textContent = "Translation failed. Check console for details.";
    console.error("Error:", err);
  }
}
