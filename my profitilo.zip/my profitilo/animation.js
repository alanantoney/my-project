const name = "Alan  Antoney";
const container = document.getElementById("name");
name.split("").forEach((char, i) => {
  const span = document.createElement("span");
  span.textContent = char;
  span.style.animationDelay = `${i * 0.1}s`;
  container.appendChild(span);
});
