const quizData = [
  { question: "Which planet is known as the “Red Planet”?", a: "Earth", b: "Mars", c: "Venus", d: "Jupiter", correct: "b" },
  { question: "What has a face and two hands, but no arms or legs?", a: "A chair", b: "A clock", c: "A robot", d: "A puppet", correct: "b" },
  { question: "What is the currency of Japan?", a: "Won", b: "Dollar", c: "Yuan", d: "Yen", correct: "d" },
  { question: "What is the most widely spoken language in the world?", a: "English", b: "Spanish", c: "Mandarin Chinese", d: "Arabic", correct: "c" },
  { question: "What comes once in a minute, twice in a moment, but never in a thousand years?", a: "The letter M", b: "The sun", c: "Rain", d: "An eclipse", correct: "a" },
  { question: "What has a thumb and four fingers but is not a hand?", a: "A mitten", b: "A monkey", c: "A glove", d: "A paw", correct: "c" },
  { question: "What is the tallest land animal in the world?", a: "Elephant", b: "Giraffe", c: "Ostrich", d: "Horse", correct: "b" },
  { question: "How many colours are there in a rainbow?", a: "6", b: "8", c: "7", d: "5", correct: "c" },
  { question: "What is the largest species of shark?", a: "Great White", b: "Whale Shark", c: "Tiger Shark", d: "Hammerhead", correct: "b" },
  { question: "What do you call a baby kangaroo?", a: "Cub", b: "Calf", c: "Joey", d: "Kid", correct: "c" },
  { question: "What do you call a baby cat?", a: "Kit", b: "Kitten", c: "Cub", d: "Pup", correct: "b" },
  { question: "What do you call a baby butterfly?", a: "Larva", b: "Worm", c: "Caterpillar", d: "Pupa", correct: "c" },
  { question: "What do you call a baby horse?", a: "Colt", b: "Pony", c: "Foal", d: "Calf", correct: "c" },
  { question: "In French, what does “merci” mean?", a: "Please", b: "Hello", c: "Goodbye", d: "Thank you", correct: "d" },
  { question: "Which famous scientist developed the theory of gravity after an apple fell on his head?", a: "Albert Einstein", b: "Galileo Galilei", c: "Isaac Newton", d: "Nikola Tesla", correct: "c" },
  { question: "Which Disney movie features a genie who can grant three wishes?", a: "Frozen", b: "Aladdin", c: "Tangled", d: "Moana", correct: "b" },
  { question: "What is the opposite of “build”?", a: "Destroy", b: "Create", c: "Assemble", d: "Raise", correct: "a" },
  { question: "What is the tallest mountain in the world?", a: "K2", b: "Mount Kilimanjaro", c: "Mount Everest", d: "Denali", correct: "c" },
  { question: "How many continents are there on Earth?", a: "5", b: "6", c: "7", d: "8", correct: "c" },
  { question: "What is the capital city of France?", a: "Rome", b: "Paris", c: "Madrid", d: "Berlin", correct: "b" },
  { question: "What is the largest land animal?", a: "Giraffe", b: "Rhino", c: "African elephant", d: "Hippopotamus", correct: "c" },
  { question: "What is a synonym?", a: "A homophone", b: "A same-sounding word", c: "A word with similar meaning", d: "An opposite word", correct: "c" },
  { question: "What is the opposite of “transparent”?", a: "Translucent", b: "Opaque", c: "Glossy", d: "Solid", correct: "b" },
  { question: "What is the opposite of “expand”?", a: "Contract", b: "Grow", c: "Open", d: "Enlarge", correct: "a" },
  { question: "What is the process by which plants use sunlight to make food?", a: "Digestion", b: "Fermentation", c: "Respiration", d: "Photosynthesis", correct: "d" },
  { question: "Which element is represented by the symbol ‘Fe’?", a: "Lead", b: "Iron", c: "Fluorine", d: "Zinc", correct: "b" },
  { question: "Which Italian dish has layers of pasta, cheese, and sauce?", a: "Spaghetti", b: "Risotto", c: "Lasagna", d: "Ravioli", correct: "c" },
  { question: "What fruit is used to make raisins?", a: "Plums", b: "Dates", c: "Grapes", d: "Figs", correct: "c" },
  { question: "Which company is known for using a lot of hazelnuts (e.g. in Nutella)?", a: "Nestle", b: "Mars", c: "Cadbury", d: "Ferrero", correct: "d" }
];

const quiz = document.getElementById("quiz");
const answerEls = document.querySelectorAll(".answer");
const questionEl = document.getElementById("question");
const a_text = document.getElementById("a_text");
const b_text = document.getElementById("b_text");
const c_text = document.getElementById("c_text");
const d_text = document.getElementById("d_text");
const submitBtn = document.getElementById("submit");

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
  deselectAnswers();
  const currentQuizData = quizData[currentQuiz];
  questionEl.innerText = currentQuizData.question;
  a_text.innerText = currentQuizData.a;
  b_text.innerText = currentQuizData.b;
  c_text.innerText = currentQuizData.c;
  d_text.innerText = currentQuizData.d;
}

function deselectAnswers() {
  answerEls.forEach((answerEl) => (answerEl.checked = false));
}

function getSelected() {
  let answer;
  answerEls.forEach((answerEl) => {
    if (answerEl.checked) {
      answer = answerEl.id;
    }
  });
  return answer;
}

submitBtn.addEventListener("click", () => {
  const answer = getSelected();
  if (answer) {
    if (answer === quizData[currentQuiz].correct) {
      score++;
    }

    currentQuiz++;

    if (currentQuiz < quizData.length) {
      loadQuiz();
    } else {
      quiz.innerHTML = `
        <h2>You answered ${score}/${quizData.length} correctly!</h2>
        <button onclick="location.reload()">Try Again</button>
      `;
    }
  }
});

