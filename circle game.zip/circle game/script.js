const circle = document.getElementById("circle");
const scoreDisplay = document.getElementById("score");
let score = 0;

// Function to move the circle to a random location
function moveCircle() {
  const maxX = window.innerWidth - 100;
  const maxY = window.innerHeight - 100;
  const randomX = Math.random() * maxX;
  const randomY = Math.random() * maxY;

  circle.style.left = `${randomX}px`;
  circle.style.top = `${randomY}px`;
}

// When the circle is clicked
circle.addEventListener("click", () => {
  score++;
  scoreDisplay.textContent = score;
  moveCircle();
});

// Start by placing the circle somewhere random
moveCircle();
